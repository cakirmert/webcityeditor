# Bundled JavaScript dependencies

Generated from package-lock.json. This conservative inventory includes production dependencies even when tree-shaking omits their code.

| Package | Declared license | License/notice files |
| --- | --- | --- |
| @deck.gl/core@9.3.4 | MIT | [LICENSE](licenses/npm/@deck.gl__core/LICENSE) |
| @deck.gl/extensions@9.3.7 | MIT | [LICENSE](licenses/npm/@deck.gl__extensions/LICENSE) |
| @deck.gl/geo-layers@9.3.7 | MIT | [LICENSE](licenses/npm/@deck.gl__geo-layers/LICENSE) |
| @deck.gl/layers@9.3.4 | MIT | [LICENSE](licenses/npm/@deck.gl__layers/LICENSE) |
| earcut@2.2.4 | ISC | [LICENSE](licenses/npm/@deck.gl__layers__earcut/LICENSE) |
| @deck.gl/mapbox@9.3.4 | MIT | [LICENSE](licenses/npm/@deck.gl__mapbox/LICENSE) |
| @deck.gl/mesh-layers@9.3.4 | MIT | [LICENSE](licenses/npm/@deck.gl__mesh-layers/LICENSE) |
| @floating-ui/core@1.7.5 | MIT | [LICENSE](licenses/npm/@floating-ui__core/LICENSE) |
| @floating-ui/dom@1.7.6 | MIT | [LICENSE](licenses/npm/@floating-ui__dom/LICENSE) |
| @floating-ui/react-dom@2.1.8 | MIT | [LICENSE](licenses/npm/@floating-ui__react-dom/LICENSE) |
| @floating-ui/utils@0.2.11 | MIT | [LICENSE](licenses/npm/@floating-ui__utils/LICENSE) |
| @loaders.gl/3d-tiles@4.4.3 | MIT | [LICENSE](licenses/npm/@loaders.gl__3d-tiles/LICENSE) |
| long@5.3.2 | Apache-2.0 | [LICENSE](licenses/npm/@loaders.gl__3d-tiles__long/LICENSE) |
| @loaders.gl/compression@4.4.3 | MIT | [LICENSE](licenses/npm/@loaders.gl__compression/LICENSE) |
| fflate@0.7.4 | MIT | [LICENSE](licenses/npm/@loaders.gl__compression__fflate/LICENSE) |
| @loaders.gl/core@4.4.3 | MIT | [LICENSE](licenses/npm/@loaders.gl__core/LICENSE) |
| @loaders.gl/crypto@4.4.3 | MIT | [LICENSE](licenses/npm/@loaders.gl__crypto/LICENSE) |
| @loaders.gl/draco@4.4.3 | MIT | [LICENSE](licenses/npm/@loaders.gl__draco/LICENSE) |
| @loaders.gl/geoarrow@4.4.3 | MIT | [LICENSE](licenses/npm/@loaders.gl__geoarrow/LICENSE) |
| @loaders.gl/gis@4.4.3 | MIT | [LICENSE](licenses/npm/@loaders.gl__gis/LICENSE) |
| @mapbox/point-geometry@0.1.0 | ISC | [LICENSE](licenses/npm/@loaders.gl__gis__@mapbox__point-geometry/LICENSE) |
| @mapbox/vector-tile@1.3.1 | BSD-3-Clause | [LICENSE.txt](licenses/npm/@loaders.gl__gis__@mapbox__vector-tile/LICENSE.txt) |
| pbf@3.3.0 | BSD-3-Clause | [LICENSE](licenses/npm/@loaders.gl__gis__pbf/LICENSE) |
| @loaders.gl/gltf@4.4.3 | MIT | [LICENSE](licenses/npm/@loaders.gl__gltf/LICENSE) |
| @loaders.gl/images@4.4.3 | MIT | [LICENSE](licenses/npm/@loaders.gl__images/LICENSE) |
| @loaders.gl/loader-utils@4.4.3 | MIT | [LICENSE](licenses/npm/@loaders.gl__loader-utils/LICENSE) |
| @loaders.gl/math@4.4.3 | MIT | [LICENSE](licenses/npm/@loaders.gl__math/LICENSE) |
| @loaders.gl/mvt@4.4.3 | MIT | [LICENSE](licenses/npm/@loaders.gl__mvt/LICENSE) |
| pbf@3.3.0 | BSD-3-Clause | [LICENSE](licenses/npm/@loaders.gl__mvt__pbf/LICENSE) |
| @loaders.gl/schema@4.4.3 | MIT | [LICENSE](licenses/npm/@loaders.gl__schema/LICENSE) |
| @loaders.gl/schema-utils@4.4.3 | MIT | [LICENSE](licenses/npm/@loaders.gl__schema-utils/LICENSE) |
| @loaders.gl/terrain@4.4.3 | MIT | [LICENSE](licenses/npm/@loaders.gl__terrain/LICENSE) |
| @loaders.gl/textures@4.4.3 | MIT | [LICENSE](licenses/npm/@loaders.gl__textures/LICENSE) |
| @loaders.gl/tiles@4.4.3 | MIT | [LICENSE](licenses/npm/@loaders.gl__tiles/LICENSE) |
| @loaders.gl/wms@4.4.3 | MIT | [LICENSE](licenses/npm/@loaders.gl__wms/LICENSE) |
| @loaders.gl/worker-utils@4.4.3 | MIT | [LICENSE](licenses/npm/@loaders.gl__worker-utils/LICENSE) |
| @loaders.gl/xml@4.4.3 | MIT | [LICENSE](licenses/npm/@loaders.gl__xml/LICENSE) |
| @loaders.gl/zip@4.4.3 | MIT | [LICENSE](licenses/npm/@loaders.gl__zip/LICENSE) |
| @luma.gl/core@9.3.3 | MIT | [LICENSE](licenses/npm/@luma.gl__core/LICENSE) |
| @luma.gl/engine@9.3.3 | MIT | [LICENSE](licenses/npm/@luma.gl__engine/LICENSE) |
| @luma.gl/gltf@9.3.3 | MIT | [LICENSE](licenses/npm/@luma.gl__gltf/LICENSE) |
| @luma.gl/shadertools@9.3.3 | MIT | [LICENSE](licenses/npm/@luma.gl__shadertools/LICENSE) |
| @luma.gl/webgl@9.3.3 | MIT | [LICENSE](licenses/npm/@luma.gl__webgl/LICENSE) |
| @mapbox/jsonlint-lines-primitives@2.0.2 | See upstream | [Retained upstream text](npm-extra-notices.md) |
| @mapbox/martini@0.2.0 | ISC | [LICENSE](licenses/npm/@mapbox__martini/LICENSE) |
| @mapbox/point-geometry@1.1.0 | ISC | [LICENSE](licenses/npm/@mapbox__point-geometry/LICENSE) |
| @mapbox/tiny-sdf@2.2.0 | BSD-2-Clause | [LICENSE.txt](licenses/npm/@mapbox__tiny-sdf/LICENSE.txt) |
| @mapbox/unitbezier@0.0.1 | BSD-2-Clause | [LICENSE](licenses/npm/@mapbox__unitbezier/LICENSE) |
| @mapbox/vector-tile@2.0.5 | BSD-3-Clause | [LICENSE.txt](licenses/npm/@mapbox__vector-tile/LICENSE.txt) |
| @mapbox/whoots-js@3.1.0 | ISC | [LICENSE.md](licenses/npm/@mapbox__whoots-js/LICENSE.md) |
| @maplibre/geojson-vt@6.1.0 | ISC | [LICENSE](licenses/npm/@maplibre__geojson-vt/LICENSE) |
| @maplibre/maplibre-gl-style-spec@24.10.0 | ISC | [LICENSE.txt](licenses/npm/@maplibre__maplibre-gl-style-spec/LICENSE.txt) |
| @mapbox/unitbezier@1.0.0 | BSD-2-Clause | [LICENSE](licenses/npm/@maplibre__maplibre-gl-style-spec__@mapbox__unitbezier/LICENSE) |
| @maplibre/mlt@1.1.11 | (MIT OR Apache-2.0) | [LICENSE.txt](licenses/npm/@maplibre__mlt/LICENSE.txt) |
| @maplibre/vt-pbf@4.3.2 | MIT | [LICENSE](licenses/npm/@maplibre__vt-pbf/LICENSE) |
| pbf@5.1.0 | BSD-3-Clause | [LICENSE](licenses/npm/@maplibre__vt-pbf__pbf/LICENSE) |
| @math.gl/core@4.1.0 | MIT | [LICENSE](licenses/npm/@math.gl__core/LICENSE) |
| @math.gl/culling@4.1.0 | MIT | [LICENSE](licenses/npm/@math.gl__culling/LICENSE) |
| @math.gl/geospatial@4.1.0 | MIT | [LICENSE](licenses/npm/@math.gl__geospatial/LICENSE) |
| @math.gl/polygon@4.1.0 | MIT | [LICENSE](licenses/npm/@math.gl__polygon/LICENSE) |
| @math.gl/sun@4.1.0 | MIT | [LICENSE](licenses/npm/@math.gl__sun/LICENSE) |
| @math.gl/types@4.1.0 | MIT | [LICENSE](licenses/npm/@math.gl__types/LICENSE) |
| @math.gl/web-mercator@4.1.0 | MIT | [LICENSE](licenses/npm/@math.gl__web-mercator/LICENSE) |
| @nodable/entities@3.0.0 | MIT | [Retained upstream text](npm-extra-notices.md) |
| @probe.gl/env@4.1.1 | MIT | [LICENSE](licenses/npm/@probe.gl__env/LICENSE) |
| @probe.gl/log@4.1.1 | MIT | [LICENSE](licenses/npm/@probe.gl__log/LICENSE) |
| @probe.gl/stats@4.1.1 | MIT | [LICENSE](licenses/npm/@probe.gl__stats/LICENSE) |
| @radix-ui/number@1.1.2 | MIT | [LICENSE](licenses/npm/@radix-ui__number/LICENSE) |
| @radix-ui/primitive@1.1.4 | MIT | [LICENSE](licenses/npm/@radix-ui__primitive/LICENSE) |
| @radix-ui/react-arrow@1.1.10 | MIT | [LICENSE](licenses/npm/@radix-ui__react-arrow/LICENSE) |
| @radix-ui/react-collection@1.1.10 | MIT | [LICENSE](licenses/npm/@radix-ui__react-collection/LICENSE) |
| @radix-ui/react-compose-refs@1.1.3 | MIT | [LICENSE](licenses/npm/@radix-ui__react-compose-refs/LICENSE) |
| @radix-ui/react-context@1.1.4 | MIT | [LICENSE](licenses/npm/@radix-ui__react-context/LICENSE) |
| @radix-ui/react-dialog@1.1.17 | MIT | [LICENSE](licenses/npm/@radix-ui__react-dialog/LICENSE) |
| @radix-ui/react-direction@1.1.2 | MIT | [LICENSE](licenses/npm/@radix-ui__react-direction/LICENSE) |
| @radix-ui/react-dismissable-layer@1.1.13 | MIT | [LICENSE](licenses/npm/@radix-ui__react-dismissable-layer/LICENSE) |
| @radix-ui/react-focus-guards@1.1.4 | MIT | [LICENSE](licenses/npm/@radix-ui__react-focus-guards/LICENSE) |
| @radix-ui/react-focus-scope@1.1.10 | MIT | [LICENSE](licenses/npm/@radix-ui__react-focus-scope/LICENSE) |
| @radix-ui/react-id@1.1.2 | MIT | [LICENSE](licenses/npm/@radix-ui__react-id/LICENSE) |
| @radix-ui/react-label@2.1.10 | MIT | [LICENSE](licenses/npm/@radix-ui__react-label/LICENSE) |
| @radix-ui/react-popper@1.3.1 | MIT | [LICENSE](licenses/npm/@radix-ui__react-popper/LICENSE) |
| @radix-ui/react-portal@1.1.12 | MIT | [LICENSE](licenses/npm/@radix-ui__react-portal/LICENSE) |
| @radix-ui/react-presence@1.1.6 | MIT | [LICENSE](licenses/npm/@radix-ui__react-presence/LICENSE) |
| @radix-ui/react-primitive@2.1.6 | MIT | [LICENSE](licenses/npm/@radix-ui__react-primitive/LICENSE) |
| @radix-ui/react-select@2.3.1 | MIT | [LICENSE](licenses/npm/@radix-ui__react-select/LICENSE) |
| @radix-ui/react-slot@1.3.0 | MIT | [LICENSE](licenses/npm/@radix-ui__react-slot/LICENSE) |
| @radix-ui/react-use-callback-ref@1.1.2 | MIT | [LICENSE](licenses/npm/@radix-ui__react-use-callback-ref/LICENSE) |
| @radix-ui/react-use-controllable-state@1.2.3 | MIT | [LICENSE](licenses/npm/@radix-ui__react-use-controllable-state/LICENSE) |
| @radix-ui/react-use-effect-event@0.0.3 | MIT | [LICENSE](licenses/npm/@radix-ui__react-use-effect-event/LICENSE) |
| @radix-ui/react-use-escape-keydown@1.1.2 | MIT | [LICENSE](licenses/npm/@radix-ui__react-use-escape-keydown/LICENSE) |
| @radix-ui/react-use-layout-effect@1.1.2 | MIT | [LICENSE](licenses/npm/@radix-ui__react-use-layout-effect/LICENSE) |
| @radix-ui/react-use-previous@1.1.2 | MIT | [LICENSE](licenses/npm/@radix-ui__react-use-previous/LICENSE) |
| @radix-ui/react-use-rect@1.1.2 | MIT | [LICENSE](licenses/npm/@radix-ui__react-use-rect/LICENSE) |
| @radix-ui/react-use-size@1.1.2 | MIT | [LICENSE](licenses/npm/@radix-ui__react-use-size/LICENSE) |
| @radix-ui/react-visually-hidden@1.2.6 | MIT | [LICENSE](licenses/npm/@radix-ui__react-visually-hidden/LICENSE) |
| @radix-ui/rect@1.1.2 | MIT | [LICENSE](licenses/npm/@radix-ui__rect/LICENSE) |
| @swc/helpers@0.5.23 | Apache-2.0 | [LICENSE](licenses/npm/@swc__helpers/LICENSE) |
| @turf/boolean-clockwise@5.1.5 | MIT | [LICENSE](licenses/npm/@turf__boolean-clockwise/LICENSE) |
| @turf/clone@5.1.5 | MIT | [LICENSE](licenses/npm/@turf__clone/LICENSE) |
| @turf/helpers@5.1.5 | MIT | [LICENSE](licenses/npm/@turf__helpers/LICENSE) |
| @turf/invariant@5.2.0 | MIT | [LICENSE](licenses/npm/@turf__invariant/LICENSE) |
| @turf/meta@5.2.0 | MIT | [LICENSE](licenses/npm/@turf__meta/LICENSE) |
| @turf/rewind@5.1.5 | MIT | [LICENSE](licenses/npm/@turf__rewind/LICENSE) |
| @types/brotli@1.3.5 | MIT | [LICENSE](licenses/npm/@types__brotli/LICENSE) |
| @types/command-line-args@5.2.3 | MIT | [LICENSE](licenses/npm/@types__command-line-args/LICENSE) |
| @types/command-line-usage@5.0.4 | MIT | [LICENSE](licenses/npm/@types__command-line-usage/LICENSE) |
| @types/crypto-js@4.2.2 | MIT | [LICENSE](licenses/npm/@types__crypto-js/LICENSE) |
| @types/geojson@7946.0.16 | MIT | [LICENSE](licenses/npm/@types__geojson/LICENSE) |
| @types/node@24.13.1 | MIT | [LICENSE](licenses/npm/@types__node/LICENSE) |
| @types/offscreencanvas@2019.7.3 | MIT | [LICENSE](licenses/npm/@types__offscreencanvas/LICENSE) |
| @types/pako@1.0.7 | MIT | [LICENSE](licenses/npm/@types__pako/LICENSE) |
| @types/react@19.2.17 | MIT | [LICENSE](licenses/npm/@types__react/LICENSE) |
| @types/react-dom@19.2.3 | MIT | [LICENSE](licenses/npm/@types__react-dom/LICENSE) |
| a5-js@0.7.3 | Apache-2.0 | [LICENSE](licenses/npm/a5-js/LICENSE) |
| ansi-styles@4.3.0 | MIT | [license](licenses/npm/ansi-styles/license) |
| anynum@1.0.1 | MIT | [LICENSE](licenses/npm/anynum/LICENSE) |
| apache-arrow@21.1.0 | Apache-2.0 | [LICENSE.txt](licenses/npm/apache-arrow/LICENSE.txt), [NOTICE.txt](licenses/npm/apache-arrow/NOTICE.txt) |
| argparse@1.0.10 | MIT | [LICENSE](licenses/npm/argparse/LICENSE) |
| aria-hidden@1.2.6 | MIT | [LICENSE](licenses/npm/aria-hidden/LICENSE) |
| array-back@6.2.3 | MIT | [LICENSE](licenses/npm/array-back/LICENSE) |
| base64-js@1.5.1 | MIT | [LICENSE](licenses/npm/base64-js/LICENSE) |
| bignumber.js@9.3.1 | MIT | [LICENCE.md](licenses/npm/bignumber.js/LICENCE.md) |
| brotli@1.3.3 | MIT | [Retained upstream text](npm-extra-notices.md) |
| buf-compare@1.0.1 | MIT | [license](licenses/npm/buf-compare/license) |
| chalk@4.1.2 | MIT | [license](licenses/npm/chalk/license) |
| chalk-template@0.4.0 | MIT | [license](licenses/npm/chalk-template/license) |
| charenc@0.0.2 | BSD-3-Clause | [LICENSE.mkd](licenses/npm/charenc/LICENSE.mkd) |
| cityjson-threejs-loader@0.4.0 | Apache-2.0 (LICENSE; package metadata incorrectly says MIT) | [LICENSE](licenses/npm/cityjson-threejs-loader/LICENSE) |
| earcut@2.2.4 | ISC | [LICENSE](licenses/npm/cityjson-threejs-loader__earcut/LICENSE) |
| class-variance-authority@0.7.1 | Apache-2.0 | [LICENSE](licenses/npm/class-variance-authority/LICENSE) |
| clsx@2.1.1 | MIT | [license](licenses/npm/clsx/license) |
| color-convert@2.0.1 | MIT | [LICENSE](licenses/npm/color-convert/LICENSE) |
| color-name@1.1.4 | MIT | [LICENSE](licenses/npm/color-name/LICENSE) |
| command-line-args@6.0.2 | MIT | [LICENSE](licenses/npm/command-line-args/LICENSE) |
| command-line-usage@7.0.4 | MIT | [LICENCE](licenses/npm/command-line-usage/LICENCE) |
| core-assert@0.2.1 | MIT | [license](licenses/npm/core-assert/license) |
| core-util-is@1.0.3 | MIT | [LICENSE](licenses/npm/core-util-is/LICENSE) |
| crypt@0.0.2 | BSD-3-Clause | [LICENSE.mkd](licenses/npm/crypt/LICENSE.mkd) |
| csstype@3.2.3 | MIT | [LICENSE](licenses/npm/csstype/LICENSE) |
| deep-strict-equal@0.2.0 | MIT | [license](licenses/npm/deep-strict-equal/license) |
| detect-node-es@1.1.0 | MIT | [LICENSE](licenses/npm/detect-node-es/LICENSE) |
| draco3d@1.5.7 | Apache-2.0 | [Retained upstream text](npm-extra-notices.md) |
| earcut@3.0.2 | ISC | [LICENSE](licenses/npm/earcut/LICENSE) |
| fast-xml-builder@1.3.0 | MIT | [LICENSE](licenses/npm/fast-xml-builder/LICENSE) |
| fast-xml-parser@5.10.1 | MIT | [LICENSE](licenses/npm/fast-xml-parser/LICENSE) |
| find-replace@5.0.2 | MIT | [LICENSE](licenses/npm/find-replace/LICENSE) |
| flatbuffers@25.9.23 | Apache-2.0 | [LICENSE](licenses/npm/flatbuffers/LICENSE) |
| get-nonce@1.0.1 | MIT | [LICENSE](licenses/npm/get-nonce/LICENSE) |
| gl-matrix@3.4.4 | MIT | [LICENSE.md](licenses/npm/gl-matrix/LICENSE.md) |
| h3-js@4.5.0 | Apache-2.0 | [LICENSE](licenses/npm/h3-js/LICENSE), [NOTICE](licenses/npm/h3-js/NOTICE) |
| has-flag@4.0.0 | MIT | [license](licenses/npm/has-flag/license) |
| ieee754@1.2.1 | BSD-3-Clause | [LICENSE](licenses/npm/ieee754/LICENSE) |
| image-size@0.7.5 | MIT | [LICENSE](licenses/npm/image-size/LICENSE) |
| immediate@3.0.6 | MIT | [LICENSE.txt](licenses/npm/immediate/LICENSE.txt) |
| inherits@2.0.4 | ISC | [LICENSE](licenses/npm/inherits/LICENSE) |
| is-buffer@1.1.6 | MIT | [LICENSE](licenses/npm/is-buffer/LICENSE) |
| is-error@2.2.2 | MIT | [LICENSE](licenses/npm/is-error/LICENSE) |
| is-unsafe@2.0.0 | MIT | [LICENSE](licenses/npm/is-unsafe/LICENSE) |
| isarray@1.0.0 | MIT | [Retained upstream text](npm-extra-notices.md) |
| json-bignum@0.0.3 | See upstream | [LICENSE](licenses/npm/json-bignum/LICENSE) |
| json-stringify-pretty-compact@4.0.0 | MIT | [LICENSE](licenses/npm/json-stringify-pretty-compact/LICENSE) |
| jszip@3.10.1 | (MIT OR GPL-3.0-or-later) | [LICENSE.markdown](licenses/npm/jszip/LICENSE.markdown) |
| kdbush@4.1.0 | ISC | [LICENSE](licenses/npm/kdbush/LICENSE) |
| ktx-parse@0.7.1 | MIT | [LICENSE](licenses/npm/ktx-parse/LICENSE) |
| lie@3.3.0 | MIT | [license.md](licenses/npm/lie/license.md) |
| lodash.camelcase@4.3.0 | MIT | [LICENSE](licenses/npm/lodash.camelcase/LICENSE) |
| long@3.2.0 | Apache-2.0 | [LICENSE](licenses/npm/long/LICENSE) |
| lucide-react@1.21.0 | ISC | [LICENSE](licenses/npm/lucide-react/LICENSE) |
| lz4js@0.2.0 | ISC | [Retained upstream text](npm-extra-notices.md) |
| maplibre-gl@5.24.0 | BSD-3-Clause | [LICENSE.txt](licenses/npm/maplibre-gl/LICENSE.txt) |
| md5@2.3.0 | BSD-3-Clause | [LICENSE](licenses/npm/md5/LICENSE) |
| mgrs@1.0.0 | MIT | [license.md](licenses/npm/mgrs/license.md) |
| minimist@1.2.8 | MIT | [LICENSE](licenses/npm/minimist/LICENSE) |
| mjolnir.js@3.0.0 | MIT | [LICENSE](licenses/npm/mjolnir.js/LICENSE) |
| murmurhash-js@1.0.0 | MIT | [Retained upstream text](npm-extra-notices.md) |
| pako@1.0.11 | (MIT AND Zlib) | [LICENSE](licenses/npm/pako/LICENSE) |
| path-expression-matcher@1.6.2 | MIT | [LICENSE](licenses/npm/path-expression-matcher/LICENSE) |
| pbf@4.0.2 | BSD-3-Clause | [LICENSE](licenses/npm/pbf/LICENSE) |
| polyclip-ts@0.16.8 | MIT | [LICENSE](licenses/npm/polyclip-ts/LICENSE) |
| polygon-clipping@0.15.7 | MIT | [LICENSE.md](licenses/npm/polygon-clipping/LICENSE.md) |
| potpack@2.1.0 | ISC | [LICENSE](licenses/npm/potpack/LICENSE) |
| process-nextick-args@2.0.1 | MIT | [license.md](licenses/npm/process-nextick-args/license.md) |
| proj4@2.20.9 | MIT | [LICENSE.md](licenses/npm/proj4/LICENSE.md) |
| protocol-buffers-schema@3.6.1 | MIT | [LICENSE](licenses/npm/protocol-buffers-schema/LICENSE) |
| quickselect@3.0.0 | ISC | [LICENSE](licenses/npm/quickselect/LICENSE) |
| react@19.2.7 | MIT | [LICENSE](licenses/npm/react/LICENSE) |
| react-dom@19.2.7 | MIT | [LICENSE](licenses/npm/react-dom/LICENSE) |
| react-remove-scroll@2.7.2 | MIT | [LICENSE](licenses/npm/react-remove-scroll/LICENSE) |
| react-remove-scroll-bar@2.3.8 | MIT | [Retained upstream text](npm-extra-notices.md) |
| react-style-singleton@2.2.3 | MIT | [LICENSE](licenses/npm/react-style-singleton/LICENSE) |
| readable-stream@2.3.8 | MIT | [LICENSE](licenses/npm/readable-stream/LICENSE) |
| regenerator-runtime@0.14.1 | MIT | [LICENSE](licenses/npm/regenerator-runtime/LICENSE) |
| resolve-protobuf-schema@2.1.0 | MIT | [LICENSE](licenses/npm/resolve-protobuf-schema/LICENSE) |
| robust-predicates@3.0.3 | Unlicense | [LICENSE](licenses/npm/robust-predicates/LICENSE) |
| safe-buffer@5.1.2 | MIT | [LICENSE](licenses/npm/safe-buffer/LICENSE) |
| scheduler@0.27.0 | MIT | [LICENSE](licenses/npm/scheduler/LICENSE) |
| setimmediate@1.0.5 | MIT | [LICENSE.txt](licenses/npm/setimmediate/LICENSE.txt) |
| snappyjs@0.6.1 | MIT | [LICENSE](licenses/npm/snappyjs/LICENSE) |
| splaytree@3.2.3 | MIT | [Retained upstream text](npm-extra-notices.md) |
| splaytree-ts@1.0.2 | BDS-3-Clause | [LICENSE](licenses/npm/splaytree-ts/LICENSE) |
| sprintf-js@1.0.3 | BSD-3-Clause | [LICENSE](licenses/npm/sprintf-js/LICENSE) |
| string_decoder@1.1.1 | MIT | [LICENSE](licenses/npm/string_decoder/LICENSE) |
| strnum@2.4.1 | MIT | [LICENSE](licenses/npm/strnum/LICENSE) |
| supports-color@7.2.0 | MIT | [license](licenses/npm/supports-color/license) |
| table-layout@4.1.1 | MIT | [LICENSE](licenses/npm/table-layout/LICENSE) |
| tailwind-merge@3.6.0 | MIT | [LICENSE.md](licenses/npm/tailwind-merge/LICENSE.md) |
| terra-draw@1.31.2 | MIT | [Retained upstream text](npm-extra-notices.md) |
| terra-draw-maplibre-gl-adapter@1.4.1 | MIT | [Retained upstream text](npm-extra-notices.md) |
| texture-compressor@1.0.2 | MIT | [LICENSE](licenses/npm/texture-compressor/LICENSE) |
| three@0.184.0 | MIT | [LICENSE](licenses/npm/three/LICENSE) |
| tinyqueue@3.0.0 | ISC | [LICENSE](licenses/npm/tinyqueue/LICENSE) |
| tslib@2.8.1 | 0BSD | [LICENSE.txt](licenses/npm/tslib/LICENSE.txt) |
| typical@7.3.0 | MIT | [LICENSE](licenses/npm/typical/LICENSE) |
| undici-types@7.18.2 | MIT | [LICENSE](licenses/npm/undici-types/LICENSE) |
| use-callback-ref@1.3.3 | MIT | [LICENSE](licenses/npm/use-callback-ref/LICENSE) |
| use-sidecar@1.1.3 | MIT | [LICENSE](licenses/npm/use-sidecar/LICENSE) |
| util-deprecate@1.0.2 | MIT | [LICENSE](licenses/npm/util-deprecate/LICENSE) |
| web-ifc@0.0.77 | MPL-2.0 | [LICENSE.md](licenses/npm/web-ifc/LICENSE.md) |
| wkt-parser@1.5.5 | MIT | [LICENSE.md](licenses/npm/wkt-parser/LICENSE.md) |
| wordwrapjs@5.1.1 | MIT | [LICENSE](licenses/npm/wordwrapjs/LICENSE) |
| xml-naming@0.3.0 | MIT | [LICENSE](licenses/npm/xml-naming/LICENSE) |
| zstd-codec@0.1.5 | MIT | [Retained upstream text](npm-extra-notices.md) |

Packages without root license files, and web-ifc 0.0.77 corresponding source, are covered in [additional retained notices](npm-extra-notices.md).

Rust/WASM dependencies and embedded OSM country-boundary data have separate notices in [WASM-NOTICES.md](WASM-NOTICES.md). Sample buildings have [DATA-NOTICES.md](DATA-NOTICES.md).
