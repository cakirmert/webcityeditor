import type { RoadBand, RoadBandKind, RoadDraft, RoadSectionDraft } from './road-types.js';
export interface RoadWidthRule {
    minimumM: number;
    recommendedM: number;
    /** Editable project guardrail, not a statutory maximum. */
    maximumM?: number;
    twoWayMinimumM?: number;
    twoWayRecommendedM?: number;
    twoWayMaximumM?: number;
    source: string;
    note: string;
}
/** Versioned design thresholds and source notes, stored with the road layout. */
export interface RoadRuleProfile {
    id: string;
    name: string;
    version: string;
    widths: Record<RoadBandKind, RoadWidthRule>;
}
export declare const HAMBURG_ROAD_RULES: RoadRuleProfile;
export declare function roadWidthRule(band: RoadBand, profile?: RoadRuleProfile): RoadWidthRule;
export interface RoadRuleIssue {
    sectionId: string;
    bandIndex?: number;
    severity: 'error' | 'warning';
    code: 'width' | 'recommendation' | 'extent' | 'configuration';
    message: string;
}
export declare function roadSectionExtents(section: RoadSectionDraft): {
    widthM: number;
    leftM: number;
    rightM: number;
};
/** Explicit acceptance covers design limits, never invalid geometry inputs. */
export declare function canAcceptRoadRuleWarning(issue: RoadRuleIssue, draft: RoadDraft): boolean;
export declare function validateRoadRules(draft: RoadDraft, baseline?: RoadDraft | null): RoadRuleIssue[];
/** Fit available surplus, never scale a pedestrian or travel lane below its own floor. */
export declare function fitRoadDraftToRules(draft: RoadDraft): {
    draft: RoadDraft;
    error?: string;
};
/** Strictly validate custom policy files before they can govern generation. */
export declare function parseRoadRuleProfile(value: unknown): RoadRuleProfile;
