import type { AttributeValue, CityJsonDocument, CityObject } from '../types-cityjson.js';
export type ValidationResult = {
    ok: true;
    doc: CityJsonDocument;
} | {
    ok: false;
    error: string;
};
export interface CityJsonSeqFeatureValue {
    type: string;
    id: string;
    CityObjects: Record<string, CityObject>;
    vertices: [number, number, number][];
}
/**
 * Validate that a parsed JSON object is a CityJSON document we can handle.
 * Does not run cjio-level schema validation - we check the structural minimums
 * the renderer and edit pipeline need.
 */
export declare function validateCityJson(data: unknown): ValidationResult;
/** Parse raw text and validate in one step. */
export declare function parseCityJson(text: string): ValidationResult;
/**
 * Auto-detect between monolithic CityJSON and CityJSONSeq (one JSON per line,
 * first line = header, subsequent lines = CityJSONFeature) and parse
 * accordingly, assembling into a single in-memory CityJsonDocument.
 *
 * Use this from the FileLoader; it replaces the plain `parseCityJson` call and
 * handles both formats transparently.
 */
export declare function parseCityJsonAuto(text: string, limitFeatures?: number, viewportBbox?: [number, number, number, number]): ValidationResult;
/**
 * Parse a CityJSONSeq file (newline-delimited: header + N CityJSONFeatures)
 * into a single merged CityJsonDocument.
 *
 * Each CityJSONFeature has its own local `vertices` array; we rewrite its
 * geometry boundaries to reference a combined global vertices array. For
 * feature counts into the thousands this is fine in memory; above that,
 * pass `limitFeatures` to load only the first N.
 *
 * `viewportBbox` (optional, in the data's CRS - same coords as the decoded
 * vertices, NOT WGS84) skips features whose vertex bbox doesn't intersect.
 * This is a big memory win on city-scale CityJSONSeq files: only the tiles
 * the user is actually looking at get parsed and held in memory.
 */
export declare function parseCityJsonSeq(text: string, limitFeatures?: number, viewportBbox?: [number, number, number, number]): ValidationResult;
export declare function createCityJsonSeqDocument(header: CityJsonDocument): CityJsonDocument;
export declare function appendCityJsonSeqFeature(doc: CityJsonDocument, feature: CityJsonSeqFeatureValue, viewportBbox?: [number, number, number, number]): boolean;
/**
 * Return the set of IDs that are root top-level buildings (no parent).
 * Filters out BuildingParts and non-building objects.
 */
export declare function rootBuildingIds(doc: CityJsonDocument): string[];
/**
 * Apply an attribute edit in place on a CityJSON document.
 * Returns true if the document was actually mutated.
 */
export declare function setAttribute(doc: CityJsonDocument, objectId: string, key: string, value: AttributeValue): boolean;
/**
 * Compute attribute-level diff between two CityJSON snapshots.
 * Used in tests and to surface "what changed" to the user.
 */
export interface AttrDiff {
    objectId: string;
    key: string;
    before: AttributeValue;
    after: AttributeValue;
}
export declare function diffAttributes(before: CityJsonDocument, after: CityJsonDocument): AttrDiff[];
/**
 * Build a tiny in-memory CityJSON 2.0 sample (one cube with semantic surfaces).
 * Used by the "sample" button and by tests.
 */
export declare function buildSampleCube(): CityJsonDocument;
/** Human-friendly short CRS display ("EPSG:4978" from full OGC URL). */
export declare function shortCrs(crs: string): string;
