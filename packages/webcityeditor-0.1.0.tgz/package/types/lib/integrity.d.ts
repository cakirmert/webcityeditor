import type { CityJsonDocument } from '../types-cityjson.js';
export type IntegritySeverity = 'error' | 'warning' | 'info';
export interface IntegrityIssue {
    severity: IntegritySeverity;
    /** Short, machine-readable code (e.g. 'vertex-index-out-of-range'). */
    code: string;
    /** One-line human-readable description suitable for direct UI display. */
    message: string;
    /** Optional location info — CityObject id, geometry index, etc. */
    location?: {
        objectId?: string;
        geometryIndex?: number;
        faceIndex?: number;
        vertexIndex?: number;
    };
}
export interface IntegrityReport {
    /** True iff there are zero `error`-severity issues. Warnings/info don't
     *  block — they're advisory (e.g. orphaned vertices after regeneration). */
    ok: boolean;
    issues: IntegrityIssue[];
    counts: {
        error: number;
        warning: number;
        info: number;
    };
    /** Summary counts of what was scanned. */
    summary: {
        cityObjects: number;
        vertices: number;
        referencedVertices: number;
        orphanedVertices: number;
    };
}
/**
 * Walk a CityJsonDocument and report every structural inconsistency we can
 * find without a network call. Designed for "light schema validation" — fast,
 * deterministic, focused on the kinds of damage that actually break our
 * downstream tools (vertex-index bounds, semantics-index bounds, parent/
 * child reference loops, orphaned vertices, missing transforms).
 *
 * For full CityJSON 2.0 schema validation, use official `cjval` server-side.
 * This is the in-browser equivalent that catches what matters for the
 * editor's interactive workflow.
 */
export declare function checkIntegrity(doc: CityJsonDocument): IntegrityReport;
