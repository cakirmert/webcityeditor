import { type EditorHandle, type EditorOptions } from './protocol.js';
export { EditorError } from './protocol.js';
export type { EditorHandle, EditorOptions, EditorSelection, EditorState, LoadDocumentOptions } from './protocol.js';
export type { CityJsonDocument, CityObject } from '../types-cityjson.js';
/** Mount an isolated editor without changing host styles or keyboard handlers. */
export declare function createEditor(container: HTMLElement, options: EditorOptions): EditorHandle;
